
//AUTO POPUP
window.addEventListener("load",function(){
    document.getElementsByClassName("popup")[0].classList.add("active");
});

document.getElementById("submit-popup-btn").addEventListener("click",function(){
    document.getElementsByClassName("popup")[0].classList.remove("active");
});
// Qoutation Partner Prices
document.getElementById("open-qoute-btn").addEventListener("click",function(){
    document.getElementsByClassName("popup2")[0].classList.add("active--qoute");

});
document.getElementById("btn__booking").addEventListener("click",function(){
    document.getElementsByClassName("popup2")[0].classList.remove("active--qoute");
});
// Body Parts


