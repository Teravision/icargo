<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Level HTML Template by Tooplate</title>

    <!-- load stylesheets -->
    <script src="font-awesome-4.7.0/css/all.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700">  <!-- Google web font "Open Sans" -->
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">                <!-- Font Awesome -->
    <link rel="stylesheet" href="css/bootstrap.min.css">                                      <!-- Bootstrap style -->
    <link rel="stylesheet" type="text/css" href="slick/slick.css"/>
    <link rel="stylesheet" type="text/css" href="slick/slick-theme.css"/>
    <link rel="stylesheet" type="text/css" href="css/datepicker.css"/>
    <link rel="stylesheet" href="css/tooplate-style.css">                                   <!-- Templatemo style -->
    <link rel="stylesheet" href="free.css">
<style>
    
</style>
    
</head>

    <body>
        <div class="tm-main-content" id="top">
            <div class="tm-top-bar-bg"></div>
            <div class="tm-top-bar" id="tm-top-bar">
                <!-- Top Navbar -->
                <div class="container">
                    <div class="row">
                        
                        <nav class="navbar navbar-expand-lg narbar-light">
                            <a class="navbar-brand mr-auto" href="#">
                                <img src="icargoimages/cargologo.png" alt="Site logo" class="icargo__logo">
                                
                            </a>
                            <button type="button" id="nav-toggle" class="navbar-toggler collapsed" data-toggle="collapse" data-target="#mainNav" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div id="mainNav" class="collapse navbar-collapse tm-bg-white">
                                <ul class="navbar-nav ml-auto">
                                  <li class="nav-item">
                                    <a class="nav-link" href="#top">Home <span class="sr-only">(current)</span></a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="#tm-section-4">About Us</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="#tm-section-5">Services</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="tracking_cargo.html">Track</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="#tm-section-6">Contact Us</a>
                                  </li>
                                  <li class="nav-item">
                                    <a class="nav-link" href="/">Sign Up</a>
                                  </li>
                                </ul>
                            </div>                            
                        </nav> 
                    </div>
                </div>
            </div>

         
            
         
            <div class="tm-bg-video">
                <div class="tracking__container">

                    <div class="tracking__wrap ">
                        <h1>Icargo Track & Trace</h1>
                        <input type="text" name="trackingnumber" class="tracking_input" id="" placeholder="Enter valid tracking no.">
                        <button>TRACK</button>
                    </div>
                </div>
                
                <div class="divclasstable">
                    <table class="tablecollapses">
                    <tbody><tr class="trheightres">
                    <td class="n2020table-tracktrace">From NAT'L CAPITAL REGION</td>
                    <td class="n2020table-tracktrace">No. of days.</td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to NAT'L CAPITAL REGION</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">1</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to SOUTH LUZON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">1-2</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to NORTH LUZON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">1-2</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to VISAYAS</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">3-5</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to MINDANAO</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                     <div class="n2020tbsolotd">4-6</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to PUERTO PRINCESA</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">3-4</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to BATANES</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd"> <div>30 days </div> (once a month voyage)</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to CORON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">3-4</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">Luzon Island;
                    Marinduque, Masbate, Mindoro, Catanduanes
                    </div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">3-4</div>
                    </td>
                    </tr>
                    <tr class="trheightres">
                    <td class="n2020table-tracktrace">From NORTH/SOUTH LUZON</td>
                    <td class="n2020table-tracktrace">No. of days.</td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to NAT'L CAPITAL REGION</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">1-2</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to SOUTH LUZON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">1-2</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to NORTH LUZON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">1-2</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to VISAYAS</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">5-7</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to MINDANAO</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">6-8</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to PUERTO PRINCESA</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">4-5</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to BATANES</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd"> <div>30 days </div> (once a month voyage)</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to CORON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">4-5</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">Luzon Island;
                    Marinduque, Masbate, Mindoro, Catanduanes
                    </div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">4-5</div>
                    </td>
                    </tr>
                    <tr class="trheightres">
                    <td class="n2020table-tracktrace">From VISAYAS</td>
                    <td class="n2020table-tracktrace">No. of days.</td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to NAT'L CAPITAL REGION</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">3-5</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to SOUTH LUZON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">5-7</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to NORTH LUZON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">5-7</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to VISAYAS</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">3-5</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to MINDANAO</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">3-5</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to PUERTO PRINCESA</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">6-7</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to BATANES</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd"> <div>30 days </div>
                    (once a month voyage)
                    </div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to CORON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">6-7</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to BATANES</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd"> <div>30 days </div>
                    (once a month voyage)
                    </div>
                    </td>
                    </tr>
                    <tr class="trheightres">
                    <td class="n2020table-tracktrace">From MINDANAO</td>
                    <td class="n2020table-tracktrace">No. of days.</td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to NAT'L CAPITAL REGION</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">4-6</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to SOUTH LUZON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">6-8</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to NORTH LUZON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">6-8</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to VISAYAS</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">3-5</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to MINDANAO</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">3-5</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to PUERTO PRINCESA</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">7-8</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to BATANES</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd"> <div>30 days </div>
                    (once a month voyage)
                    </div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd">to CORON</div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">7-8</div>
                    </td>
                    </tr>
                    <tr>
                    <td class="n2020border-added">
                    <div class="n2020tbsolotd"> Luzon Island;
                    Marinduque, Masbate, Mindoro, Catanduanes
                    </div>
                    </td>
                    <td class="tbcelsolo n2020border-added">
                    <div class="n2020tbsolotd">7-8</div>
                    </td>
                    </tr>
                    </tbody></table>
                </div> 
   
            </div>           
            <div class="footer__container">

                <div class="footer__links">
                    <div class="footer__link--wrapper">
                        <div class="footer__link--items">
                             <h2>About Us</h2>
                             <a href="/">How It Works</a>
                             <a href="/">Testimony</a>
                             <a href="/">Investments</a>
                             <a href="/">Terms Of Services</a>
                        </div>
                        <div class="footer__link--items">
                             <h2>Contact Us</h2>
                             <a href="/">How It Works</a>
                             <a href="/">Testimony</a>
                             <a href="/">Investments</a>
                             <a href="/">Terms Of Services</a>
                        </div>
                    </div>
                    <div class="footer__link--wrapper">
                        <div class="footer__link--items">
                             <h2>Others</h2>
                             <a href="/">How It Works</a>
                             <a href="/">Testimony</a>
                             <a href="/">eInvestments</a>
                             <a href="/">Terms Of Services</a>
                        </div>
                        <div class="footer__link--items">
                             <h2>Social Media</h2>
                             <a href="/">Instagram</a>
                             <a href="/">Facebook</a>
                             <a href="/">Twitter</a>
                             <a href="/">Youtube</a>
                        </div>
                    </div>
                </div>
                   
                <div class="social__media">
                    <div class="social__media--wrap">
                        <div class="footer__logo">
                            <a href="/" id="footer__logo">ICARGO</a>
                        </div>
                        <p class="website__rights">ICARGO 2021. All Rights Reserved</p>
                        <div class="social__icons">
                            <a href="/" class="social__icon--link" target="_blank">
                                <i class="fab fa-facebook"></i>
                            </a>
                            <a href="/" class="social__icon--link" target="_blank">
                                <i class="fab fa-twitter"></i>
                            </a>
                            <a href="/" class="social__icon--link" target="_blank">
                                <i class="fab fa-youtube"></i>
                            </a>
                            <a href="/" class="social__icon--link" target="_blank">
                                <i class="fab fa-instagram"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- load JS files -->
        <script src="js/jquery-1.11.3.min.js"></script>             <!-- jQuery (https://jquery.com/download/) -->
        <script src="js/popper.min.js"></script>                    <!-- https://popper.js.org/ -->       
        <script src="js/bootstrap.min.js"></script>                 <!-- https://getbootstrap.com/ -->
        <script src="js/datepicker.min.js"></script>                <!-- https://github.com/qodesmith/datepicker -->
        <script src="js/jquery.singlePageNav.min.js"></script>      <!-- Single Page Nav (https://github.com/ChrisWojcik/single-page-nav) -->
        <script src="slick/slick.min.js"></script>                  <!-- http://kenwheeler.github.io/slick/ -->
        <script>

            /* Google map
            ------------------------------------------------*/
            var map = '';
            var center;

            function initialize() {
                var mapOptions = {
                    zoom: 13,
                    center: new google.maps.LatLng(-23.013104,-43.394365),
                    scrollwheel: false
                };

                map = new google.maps.Map(document.getElementById('google-map'),  mapOptions);

                google.maps.event.addDomListener(map, 'idle', function() {
                  calculateCenter();
              });

                google.maps.event.addDomListener(window, 'resize', function() {
                  map.setCenter(center);
              });
            }

            function calculateCenter() {
                center = map.getCenter();
            }

            function loadGoogleMap(){
                var script = document.createElement('script');
                script.type = 'text/javascript';
                script.src = 'https://maps.googleapis.com/maps/api/js?key=AIzaSyDVWt4rJfibfsEDvcuaChUaZRS5NXey1Cs&v=3.exp&sensor=false&' + 'callback=initialize';
                document.body.appendChild(script);
            } 

            function setCarousel() {
                
                if ($('.tm-article-carousel').hasClass('slick-initialized')) {
                    $('.tm-article-carousel').slick('destroy');
                } 

                if($(window).width() < 438){
                    // Slick carousel
                    $('.tm-article-carousel').slick({
                        infinite: false,
                        dots: true,
                        slidesToShow: 1,
                        slidesToScroll: 1
                    });
                }
                else {
                 $('.tm-article-carousel').slick({
                        infinite: false,
                        dots: true,
                        slidesToShow: 2,
                        slidesToScroll: 1
                    });   
                }
            }

            function setPageNav(){
                if($(window).width() > 991) {
                    $('#tm-top-bar').singlePageNav({
                        currentClass:'active',
                        offset: 79
                    });   
                }
                else {
                    $('#tm-top-bar').singlePageNav({
                        currentClass:'active',
                        offset: 65
                    });   
                }
            }

            function togglePlayPause() {
                vid = $('.tmVideo').get(0);

                if(vid.paused) {
                    vid.play();
                    $('.tm-btn-play').hide();
                    $('.tm-btn-pause').show();
                }
                else {
                    vid.pause();
                    $('.tm-btn-play').show();
                    $('.tm-btn-pause').hide();   
                }  
            }
       
            $(document).ready(function(){

                $(window).on("scroll", function() {
                    if($(window).scrollTop() > 100) {
                        $(".tm-top-bar").addClass("active");
                    } else {
                        //remove the background property so it comes transparent again (defined in your css)
                       $(".tm-top-bar").removeClass("active");
                    }
                });      

                // Google Map
                loadGoogleMap();  

                // Date Picker
                const pickerCheckIn = datepicker('#inputCheckIn');
                const pickerCheckOut = datepicker('#inputCheckOut');
                
                // Slick carousel
                setCarousel();
                setPageNav();

                $(window).resize(function() {
                  setCarousel();
                  setPageNav();
                });

                // Close navbar after clicked
                $('.nav-link').click(function(){
                    $('#mainNav').removeClass('show');
                });

                // Control video    
                $('.tm-btn-play').click(function() {
                    togglePlayPause();                                      
                });

                $('.tm-btn-pause').click(function() {
                    togglePlayPause();                                      
                });

                // Update the current year in copyright
                $('.tm-current-year').text(new Date().getFullYear());                           
            });

        </script>             

</body>
</html>
