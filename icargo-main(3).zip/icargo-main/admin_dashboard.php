
<?php 

if(!isset($_SESSION)){
    session_start();
}

if(isset($_SESSION['UserLogin'])) {
    echo 'Welcome'." ". $_SESSION['UserLogin'];
}


include_once("./connection/connection.php");





?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php if(isset($_SESSION['UserLogin'])) { ?>
    <a href="./logout.php">Logout</a>
        <?php           } else {?>

    <a href="./loginpage.php">Login</a>
    
<?php   } ?>


    <h1 style="text-align: center;">ADMIN DASHBOARD</h1>
</body>
</html>