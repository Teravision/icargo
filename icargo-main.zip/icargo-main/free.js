//AUTO POPUP
window.addEventListener("load",function(){
    document.getElementsByClassName("popup")[0].classList.add("active");
});

document.getElementById("submit-popup-btn").addEventListener("click",function(){
    document.getElementsByClassName("popup")[0].classList.remove("active");
});

document.getElementById("open-qoute-btn").addEventListener("click",function(){
    document.getElementsByClassName("popup")[0].classList.add("active");
});